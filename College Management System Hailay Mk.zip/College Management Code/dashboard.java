import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class Dashboard extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setTitle("JavaFX Dashboard");

        // Create pie chart
        PieChart pieChart = new PieChart();
        PieChart.Data slice1 = new PieChart.Data("Course",1);
        PieChart.Data slice2 = new PieChart.Data("Instructors",2);
        PieChart.Data slice3 = new PieChart.Data("Student",3);
        PieChart.Data slice4 = new PieChart.Data("Student",4);
        PieChart.Data slice5 = new PieChart.Data("MarkList",5);
        PieChart.Data slice6 = new PieChart.Data("Grade",6);
        pieChart.getData().addAll(slice1, slice2, slice3);
        pieChart.setTitle("Pie Chart");

        /
        // Create layout
        GridPane gridPane = new GridPane();
        gridPane.add(pieChart, 0, 0);

        // Create scene
        Scene scene = new Scene(gridPane, 800, 600);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

        public static void main(String[] args) {
            launch(args);
        }
        Button button1 = new Button("Button 1");
            Button button2 = new Button("Button 2");
            Label label1 = new Label("Label 1");
            Label label2 = new Label("Label 2");

            // Create layout
            GridPane gridPane = new GridPane();
            gridPane.setPadding(new Insets(10));
            gridPane.setHgap(10);
            gridPane.setVgap(10);

            // Add components to the layout
            gridPane.add(pieChart, 0, 0, 2, 1);
            gridPane.add(button1, 0, 1);
            gridPane.add(button2, 1, 1);
            gridPane.add(label1, 0, 2);
            gridPane.add(label2, 1, 2);

            // Create scene
            Scene scene = new Scene(gridPane, 800, 600);
            primaryStage.setScene(scene);
            primaryStage.show();
        }

        public static void main(String[] args) {
            launch(args);
}
