public class Grade {
    private int gradeId;
    private Mark mark;
    private String grade;

    public Grade(int gradeId, Mark mark, String grade) {
        this.gradeId = gradeId;
        this.mark = mark;
        this.grade = grade;
    }

    // Getters and setters

    public int getGradeId() {
        return gradeId;
    }

    public void setGradeId(int gradeId) {
        this.gradeId = gradeId;
    }

    public Mark getMark() {
        return mark;
    }

    public void setMark(Mark mark) {
        this.mark = mark;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }
}