public class Professor {
    private int professorId;
    private String name;
    private String email;
    private String address;

    public Professor(int professorId, String name, String email, String address) {
        this.professorId = professorId;
        this.name = name;
        this.email = email;
        this.address = address;
    }

    // Getters and setters

    public int getProfessorId() {
        return professorId;
    }

    public void setProfessorId(int professorId) {
        this.professorId = professorId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}