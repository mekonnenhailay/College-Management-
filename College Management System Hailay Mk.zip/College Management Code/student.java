 import java.util.ArrayList;
import java.util.List;

public class Student {
    private int studentId;
    private String name;
    private String email;
    private String address;
    private List<Enrollment> enrolledIn;

    public Student(int studentId, String name, String email, String address) {
        this.studentId = studentId;
        this.name = name;
        this.email = email;
        this.address = address;
        this.enrolledIn = new ArrayList<>();
    }

 public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }
    
    // Other getter and setter methods

    public List<Enrollment> getEnrolledIn() {
        return enrolledIn;
    }

    public void enrollInCourse(Course course) {
        Enrollment enrollment = new Enrollment(this, course);
        enrolledIn.add(enrollment);
        course.addEnrollment(enrollment);
    }

    public void dropCourse(Course course) {
        Enrollment enrollment = findEnrollment(course);
        if (enrollment != null) {
            enrolledIn.remove(enrollment);
            course.removeEnrollment(enrollment);
        }
    }

    private Enrollment findEnrollment(Course course) {
        for (Enrollment enrollment : enrolledIn) {
            if (enrollment.getCourse() == course) {
                return enrollment;
            }
        }
        return null;
    }
}

public class Professor {
    private int professorId;
    private String name;
    private String email;
    private String address;

    public Professor(int professorId, String name, String email, String address) {
        this.professorId = professorId;
        this.name = name;
        this.email = email;
        this.address = address;
    }

    // Getters and setters

    public int getProfessorId() {
        return professorId;
    }

    public void setProfessorId(int professorId) {
        this.professorId = professorId;
    }

}

public class Course {
    private int courseId;
    private String name;
    private int credits;
    private Professor professor;
    private List<Enrollment> enrollments;

    public Course(int courseId, String name, int credits, Professor professor) {
        this.courseId = courseId;
        this.name = name;
        this.credits = credits;

}

public class Student {
    private int studentId;
    private String name;
    private String email;
    private String address;
    private List<Enrollment> enrolledIn;

    public Student(int studentId, String name, String email, String address) {
        this.studentId = studentId;
        this.name = name;
        this.email = email;
        this.address = address;
        this.enrolledIn = new ArrayList<>();
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public List<Enrollment> getEnrolledIn() {
        return enrolledIn;
    }

    public void enrollInCourse(Course course) {
        Enrollment enrollment = new Enrollment(this, course);
        enrolledIn.add(enrollment);
        course.addEnrollment(enrollment);
    }

    public void dropCourse(Course course) {
        Enrollment enrollment = findEnrollment(course);
        if (enrollment != null) {
            enrolledIn.remove(enrollment);
            course.removeEnrollment(enrollment);
        }
    }

    private Enrollment findEnrollment(Course course) {
        for (Enrollment enrollment : enrolledIn) {
            if (enrollment.getCourse() == course) {
                return enrollment;
            }
        }
        return null;
    }
}