import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Login {
    private Map<String, String> credentials;

    public Login() {
        credentials = new HashMap<>();
        // Initialize the credentials map with username and password pairs
        credentials.put("admin", "hailaymk12@#");
        credentials.put("user", "user12*&");
    }

    public boolean authenticate(String username, String password) {
        String storedPassword = credentials.get(username);
        return storedPassword != null && storedPassword.equals(password);
    }

    public static void main(String[] args) {
        Login login = new Login();

        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to Micro-Link College Management System");
        System.out.println("Please enter your username and password to login:");

        System.out.print("Username: ");
        String username = scanner.nextLine();

        System.out.print("Password: ");
        String password = scanner.nextLine();

        if (login.authenticate(username, password)) {
            System.out.println("Login successful!");
            // Perform further actions for logged-in users
        } else {
            System.out.println("Invalid username or password. Please try again.");
            // Handle login failure or display error message
        }

        scanner.close();
    }
}