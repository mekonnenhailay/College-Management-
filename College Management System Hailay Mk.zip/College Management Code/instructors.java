import java.util.ArrayList;
import java.util.List;

public class Instructor extends Professor {
    private String department;
    private List<Course> coursesTaught;

    public Instructor(int professorId, String name, String email, String address, String department) {
        super(professorId, name, email, address);
        this.department = department;
        this.coursesTaught = new ArrayList<>();
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public double calculateAverageRating() {
        // Code to calculate and return the average rating of the instructor
        // Implement your logic here
    }

    public void assignCourse(Course course) {
        coursesTaught.add(course);
    }

    public void removeCourse(Course course) {
        coursesTaught.remove(course);
    }

    public List<Course> getCoursesTaught() {
        return coursesTaught;
    }

    public int getWorkload() {
        return coursesTaught.size();
    }
    public void addInstructor(Instructor instructor) {
        instructors.add(instructor);
    }

    public void removeInstructor(Instructor instructor) {
        instructors.remove(instructor);
    }

    public List<Instructor> getAllInstructors() {
        return instructors;
    }
}