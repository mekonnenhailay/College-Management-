import java.util.ArrayList;
import java.util.List;

public class Course {
    private int courseId;
    private String name;
    private int credits;
    private Professor professor;
    private List<Enrollment> enrollments;

    public Course(int courseId, String name, int credits, Professor professor) {
        this.courseId = courseId;
        this.name = name;
        this.credits = credits;
        this.professor = professor;
        this.enrollments = new ArrayList<>();
    }

    // Getters and setters

    public int getCourseId() {
        return courseId;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCredits() {
        return credits;
    }

    public void setCredits(int credits) {
        this.credits = credits;
    }

    public Professor getProfessor() {
        return professor;
    }

    public void setProfessor(Professor professor) {
        this.professor = professor;
    }

    public List<Enrollment> getEnrollments() {
        return enrollments;
    }

    public void addEnrollment(Enrollment enrollment) {
        enrollments.add(enrollment);
    }

    public void removeEnrollment(Enrollment enrollment) {
        enrollments.remove(enrollment);
    }
}